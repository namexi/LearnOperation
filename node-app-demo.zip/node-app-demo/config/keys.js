module.exports = {
  mongoURI:
    'mongodb://localhost/MarsDB',
  secretOrKey: 'secret'
};
